// +build !amd64

package p

import (
	"indirect"
)

var in = []algo{
	{indirect.F},
}
